package checkers.model;

public interface Piece {

}
